﻿#Location of filerList.csv
$filerList = "C:\bulkAddFilers.csv"
#get Varonis stuff ready
#Import-Module -Name 'VaronisManagement'
import-module Varonis*
Connect-Idu
#for loop that adds the servers in the list. You shouldn't have to change anything below here
$filerInfo = import-csv $filerList
$filerInfo | foreach-object {
    #general variables from csv
    $filerType = $_.filerType.toLower()
    $hostname = $_.hostname
    $filewalkUser = $_.filewalkUser
    $filewalkPW = $_.filewalkPW
    $agentUser = $_.agentUser   
    $agentPW = $_.agentPW
    $databaseServerUser = $_.databaseServerUser
    $databaseServerPW = $_.databaseServerPW     
    $databaseUser = $_.databaseUser
    $databasePW = $_.databasePW
    $probeID = $_.probeID   
    $collectorID = Get-Collector -name $_.collector
    $collector = $_.collector
    $collectorUser = $_.collectorUser
    $collectorPW = $_.collectorPW
    #EMC specific variables
    $method = $_.EMCEventCollection
    #Here we are building out cases (ie..if the filer is windows, do these steps...blah blah)
    
    #test ping
    if((Test-Connection -Cn $hostname -BufferSize 16 -Count 1 -ea 0 -quiet))

    #if it responds, add it
    {
        $hostname + ": Responding to ping"
        switch ($filerType) 
        { 
            "windows" {
                    #just getting some vars ready for the actual command
                    "Adding " + $hostname
                    $fwCred = New-Varoniscredential -username $filewalkUser -password $filewalkPW -type Windows
                    $agentCred = New-Varoniscredential -username $agentUser -password $agentPW -type Windows
                    #$collectorCred = New-Varoniscredential -username $collectorUser -password $collectorPW
                    $dbServerCred = New-Varoniscredential -username $databaseServerUser -password $databaseServerPW
                    $dbSQLCred = New-Varoniscredential -username $databaseUser -password $databasePW -type Sql
                    #this separates the collector vs non-collector situations then adds the filer
                    if ([string]::IsNullOrEmpty($collector)){
                        $filer = New-WindowsFileServer -name $hostname -AddToFilteredUsers $true -FileWalkCredentials $fwcred -AgentCredentials $agentCred -ShadowSqlCredential $dbSQLCred -DBInstallCredential $dbServerCred  -ProbeID $probeID
                        #Specify that we do not want driver to be installed
                        #$filer.Config.SkipFileWalkChange = $true
                        #$filer.Config.IgnoreDriverChanges = $true
                        #$filer.Config.All.CollectLocalAccountsInfo = $true
                        #possible values:
                        # 1 = unchecked
                        # 32774 - checked 
                        #$filer.Config.All.OpenReadEvents = 32774
                        Add-fileserver $filer -AutoFillVolumes -Force
                        }
                    else {
                        $collectorCred = New-Varoniscredential -username $collectorUser -password $collectorPW
                        $filer = New-WindowsFileServer -name $hostname -AddToFilteredUsers $true -FileWalkCredentials $fwcred -AgentCredentials $agentCred -ShadowSqlCredential $dbSQLCred -DBInstallCredential $dbServerCred -ProbeID $probeID -collector $collectorID
                        #Specify that we do not want driver to be installed
                        #$filer.Config.SkipFileWalkChange = $true
                        #$filer.Config.IgnoreDriverChanges = $true
                        #$filer.Config.All.CollectLocalAccountsInfo = $true
                        #possible values:
                        # 1 = unchecked
                        # 32774 - checked 
                        #$filer.Config.All.OpenReadEvents = 32774
                        Add-fileserver $filer -AutoFillVolumes  -CollectorCredential $collectorCred -Force
                        }
                    }
            "emc" {
                    #just getting some vars ready for the actual command
                    "Adding " + $hostname
                    $fwCred = New-Varoniscredential -username $filewalkUser -password $filewalkPW                 
                    $agentCred = New-Varoniscredential -username $agentUser -password $agentPW
                    #$collectorCred = New-Varoniscredential -username $collectorUser -password $collectorPW
                    $dbServerCred = New-Varoniscredential -username $databaseServerUser -password $databaseServerPW
                    $dbSQLCred = New-Varoniscredential -username $databaseUser -password $databasePW
                    #this separates the collector vs non-collector situations then adds the filer
                    if ([string]::IsNullOrEmpty($collector)){
                        $filer = New-CelerraFileServer -method $method -name $hostname -AddToFilteredUsers $true -FileWalkCredentials $fwcred -ShadowSqlCredential $dbSQLCred -DBInstallCredential $dbServerCred -ProbeID $probeID
                        Add-fileserver $filer -AutoFillVolumes 
                        }
                    else {
                        $collectorCred = New-Varoniscredential -username $collectorUser -password $collectorPW
                        $filer = New-CelerraFileServer -method $method -name $hostname -AddToFilteredUsers $true -FileWalkCredentials $fwcred -ShadowSqlCredential $dbSQLCred -DBInstallCredential $dbServerCred -ProbeID $probeID -collector $collectorID
                        Add-fileserver $filer -AutoFillVolumes  -CollectorCredential $collectorCred
                        }
                    } 
            "netapp" {
                    #just getting some vars ready for the actual command
                    "Adding " + $hostname
                    $fwCred = New-Varoniscredential -username $filewalkUser -password $filewalkPW                 
                    #$collectorCred = New-Varoniscredential -username $collectorUser -password $collectorPW
                    $dbServerCred = New-Varoniscredential -username $databaseServerUser -password $databaseServerPW
                    $dbSQLCred = New-Varoniscredential -username $databaseUser -password $databasePW
                    #this separates the collector vs non-collector situations then adds the filer
                    if ([string]::IsNullOrEmpty($collector)){
                        $filer = New-WindowsFileServer -name $hostname -AddToFilteredUsers $true -FileWalkCredentials $fwcred -ShadowSqlCredential $dbSQLCred -DBInstallCredential $dbServerCred -ProbeID $probeID
                        Add-fileserver $filer -AutoFillVolumes 
                        }
                    else {
                        $collectorCred = New-Varoniscredential -username $collectorUser -password $collectorPW
                        $filer = New-NetAppFileServer -name $hostname -AddToFilteredUsers $true -FileWalkCredentials $fwcred -ShadowSqlCredential $dbSQLCred -DBInstallCredential $dbServerCred -ProbeID $probeID -collector $collectorID
                        Add-fileserver $filer -AutoFillVolumes  -CollectorCredential $collectorCred
                        }
                    }
        }
    
    }
    else { 
        $pingStatus = 'No Ping'
        $hostname + ": Not responding to ping"
        
        "$hostname,$pingStatus" | out-file "C:\temp\VaronisNoPing.csv" -append
        }
}