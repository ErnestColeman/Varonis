﻿Instructions for bulkAddFilers.ps1
Jonathan Thomal - 10/14/13 - jonathan@varonis.com

Limitations:
-	Using the parameter to automatically monitor all volumes not only monitors the volumes (c$, d$, etc..), but also all shares on the server (c$, c:\share, c:\share\subshare, d$, d:\share, d:\share\subshare, etc..)
-	If the sql server is separate from the IDU, the IDU machine account must be a local admin on the SQL server in order to run clr and dtc checks. There is a parameter to specify the sql server credentials (management console equivalent is SQL server host credentials), but it doesn’t appear that this parameter works correctly. Instead of impersonating the user credentials supplied, it runs using the local system account. If sql is local to the IDU, this shouldn’t be an issue
-	You cannot change the filewalk credentials via powershell..there is not a switch to use and the property is also read-only so I can’t force a change in the filer settings


Instructions:
1. Make sure you are able to execute powershell scripts. You can run Disable-PS-Security.bat to modify the execution policy on the server.
2. Verify Varonis powershell module is installed on the server. This is part of the Management Console installation.
3. Fill out bulkAddFilers.csv with the info about the servers you are adding (header descriptions are below).
4. Edit bulkAddFilers.ps1. Change the value on line 2 for the $filerList variable to the path where you have bulkAddFilers.csv saved.
5. Run bulkAddFilers.ps1. I only tested this by running it in the Powershell ISE.
6. After all filers are added, run enableLocalAccount.ps1 to enable the setting for collecting local account information.



Column header descriptions for bulkAddFilers.csv:
filerType - case sensitive. possible options are: windows, emc 
hostname - hostname of the file server to be monitored. May need to be fully qualified depending on network/DNS/etc
filewalkUser - domain account that will perform the filewalk
filewalkPW - password of the domain account that will perform the filewalk
agentUser - domain account that will install the Varonis agent 
agentPW - password of the domain account that will install the Varonis agent 
databaseServerUser - domain account that is a local admin on the SQL server 
databaseServerPW - password of domain account that is a local admin on the SQL server 
databaseUser - user account with sysadmin privileges on the SQL instance
databasePW - password for the user account with sysadmin privileges on the SQL instance
probeID - ID of the probe that will be monitoring the filer. Can be found in the probes table of vrnsdomainDB
collector - hostname of the collector that will monitor the file server. May need to be fully qualified depending on network/DNS/etc
collectorUser - domain account that will install the Varonis services on collector
CollectorPW - password of the domain account that will install the Varonis services on collector
EMCEventCollection - EMC only, case sensitive. 'cepa' is the only option I tested